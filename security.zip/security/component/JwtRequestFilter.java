package com.qnaportal.user.security.component;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.qnaportal.user.security.service.JwtDecryptorService;
import com.qnaportal.user.security.service.JwtUserDetailsService;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {
	@Autowired
	private JwtDecryptorService jwtDecryptorService;
	
	@Autowired
	private JwtUserDetailsService JwtUserDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		final String requestTokenHeader = request.getHeader("Authorization");
		String emailId = null;
		String jwtToken = null;
		if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
			jwtToken = requestTokenHeader.substring(7);
			emailId = jwtDecryptorService.getUsernameFromToken(jwtToken);
		} 
		if (emailId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			setAuthenticationTokenFromJwt(request, jwtToken, emailId);
		}

		chain.doFilter(request, response);
	}

	private void setAuthenticationTokenFromJwt(HttpServletRequest request, String jwtToken, String emailId) {
		
		UserDetails userDetails = JwtUserDetailsService.loadUserByUsername(emailId);
		if (jwtDecryptorService.validateToken(jwtToken, userDetails).booleanValue()) {
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
					userDetails, null, new ArrayList<>());
			usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
		}
	}
}
