package com.qnaportal.user.security.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.qnaportal.user.entities.dto.UserInfo;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtGenerationService {

	public static final long TOKEN_VALIDITY_IN_MINS = 10L;

	public static final long TOKEN_VALIDITY_IN_MILLIS = TOKEN_VALIDITY_IN_MINS * 60L * 1000L;

	@Value("${secret.key}")
	private String secretKey;

	public String generateToken(UserInfo userInfo) {
		Map<String, Object> claimsMap = new HashMap<>();
		claimsMap.put("userInfo", userInfo);
		return doGenerateToken(claimsMap, userInfo.getEmailId());
	}

	private String doGenerateToken(Map<String, Object> claims, String subject) {
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY_IN_MILLIS))
				.signWith(SignatureAlgorithm.HS512, secretKey).compact();
	}

}
