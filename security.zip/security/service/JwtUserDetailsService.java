package com.qnaportal.user.security.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.qnaportal.user.entities.db.TblUserInfo;
import com.qnaportal.user.repository.TblUserInfoRepository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private TblUserInfoRepository tblUserInfoRepository;

	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {

		Optional<TblUserInfo> tblUserInfoOptional = tblUserInfoRepository
				.findByEmailId(emailId);
		if (tblUserInfoOptional.isPresent()) {
			TblUserInfo tblUserInfo = tblUserInfoOptional.get();
			return new User(tblUserInfo.getEmailId(),tblUserInfo.getPassword(),
					new ArrayList<>());
		} else {
			throw new UsernameNotFoundException("User Not Found");
		}
	}

}
