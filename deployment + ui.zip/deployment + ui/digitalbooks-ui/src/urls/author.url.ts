export const authorurl = {
    url : "http://localhost:8081/api/v1/digitalbooks/author"
};