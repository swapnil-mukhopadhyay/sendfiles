export const bookurl = {
    url : "http://localhost:8080/api/v1/digitalbooks/books"
};