export const readerurl = {
    url : "http://localhost:8082/api/v1/digitalbooks/readers"
};