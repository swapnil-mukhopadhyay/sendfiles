export interface CredentialPayload{
    username:string,
    password:string
}