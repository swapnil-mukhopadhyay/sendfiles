import { BookDto } from './book.dto';

export interface BookPayload{

    bookDtoList: Array<BookDto>

}