export interface JwtResponse{
    token:string
}