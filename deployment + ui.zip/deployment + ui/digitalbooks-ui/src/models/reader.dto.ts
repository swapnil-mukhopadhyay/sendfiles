export interface ReaderDto{
    readerId?:number,
    name:string,
    emailId:string
}