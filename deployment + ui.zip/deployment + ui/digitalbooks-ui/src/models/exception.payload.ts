export interface ExceptionPayload{
    statusCode:number,
    message:string,
    time:string,
    component:string
}